import base64
import pytest
import server
import client
from Crypto import Cipher
from Crypto.Cipher import AES
import pytest
import os
import sys
import crypt
from Crypto.Cipher import AES

def test_f_1():
    print("Testa comportamento encrypt_intvalue")
    assert server.encrypt_intvalue("123", 3)  == str(base64.b64encode(encrypted),'utf8')



def test_f_2():
    print("Testa comportamento decrypt_intvalue")
    assert server.decrypt_intvalue(int(str(decrypt, 'utf8')),3) == "123"



def test_f_8():
    print("Testa comportamento com n < 1")
    #teste para nºargumentos <2
    assert server.valid_argv([""]) == "ERROR! INSUFICIENT ARGUMENTS! Please try: python3 server.py porto"
    # teste para nºargumentos >2
    assert server.valid_argv("", "", "") == "ERROR! TOO MANY ARGUMENTS! Please try: python3 server.py porto"
    #teste de argumento do tipo errado
    assert server.valid_argv("abc", "abc") == "ERROR! TOO MANY ARGUMENTS! Please try: python3 server.py porto"

