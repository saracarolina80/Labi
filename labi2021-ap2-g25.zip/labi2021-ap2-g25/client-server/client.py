#!/usr/bin/python3

import os
import sys
import socket
import json
import random
import base64
from common_comm import send_dict, recv_dict, sendrecv_dict
from Crypto import Cipher
from Crypto.Cipher import AES


# Função para encriptar valores a enviar em formato jsos com codificação base64
# return int data encrypted in a 16 bytes binary string coded in base64
def encrypt_intvalue(cipherkey, data):
    if not cipherkey:
        return data
    key = base64.b64decode(cipherkey)
    cipher = AES.new(key, AES.MODE_ECB)
    encrypted = cipher.encrypt(bytes("%16d" % (data), 'utf8'))
    tosend = str(base64.b64encode(encrypted), 'utf8')

    return tosend


# Função para desencriptar valores recebidos em formato json com codificação base64
# return int data decrypted from a 16 bytes binary strings coded in base64
def decrypt_intvalue(cipherkey, data):
    if not cipherkey:
        return data
    key = base64.b64decode(cipherkey)
    cipher = AES.new(key, AES.MODE_ECB)
    decrypt = cipher.decrypt(base64.b64decode(data))
    decrypt = int(str(decrypt, 'utf8'))
    return decrypt


# verify if response from server is valid or is an error message and act accordingly
def validate_response(client_sock, response):
    if response["status"] == False:
        print("\nError! " + response["error"])
        quitOP = sendrecv_dict(client_sock, {"op": "QUIT"})
        client_sock.close()
        exit(1)


# process QUIT operation
def quit_action(client_sock, attempts):
    quitOP = sendrecv_dict(client_sock, {"op": "QUIT"})
    validate_response(client_sock, quitOP)

    print("\nSaiste do jogo! :/  Ainda tinhas ) " + str(attempts) + " jogadas!")
    client_sock.close()
    sys.exit(0)


# Outcomming message structure:
# { op = "START", client_id, [cipher] }
# { op = "QUIT" }
# { op = "GUESS", number }
# { op = "STOP", number, attempts }
#
# Incomming message structure:
# { op = "START", status, max_attempts }
# { op = "QUIT" , status }
# { op = "GUESS", status, result }
# { op = "STOP", status, guess }



#
# Suporte da execução do cliente

## FUNÇAO INCOMPLETA
def run_client (client_sock, client_id):
    print("\t\tOlá", client_id,"vamos jogar!\n")
    print("\t\t\tREGRAS DO JOGO: \n")
    print("\t - Tente adivinhar o número secreto gerado aleatoriamente\n")
    print("\t - Existe um número máximo de tentativas que não deve ser ultrapassado para ter sucesso\n")
    
    cript = input("Deseja usar mensagens encriptadas? s ou n? ")

	

    if cript.lower() == "s":
	    key = str(base64.b64encode(os.urandom(16)),'utf8')
	
	
    resp = sendrecv_dict(client_sock,{"op":"START","client_id":client_id,"cipher": key})
	# validate_response(client_sock, resp)
     
	# max_attempts = decrypt_intvalue(key, resp["max_attempts"])
    trys = []
    max_attempts = random.randint(10,30)
    attempts = 0


    
    print("Entraste no jogo!\n"  "Tens " + str(max_attempts) +  " tentativas.\n")

    while 1:
        inp = input("Adivinha o número ou quit para sair: ")
        if inp.lower() == "quit":
            break
    
        new = input("Tenta de novo:  ")

        if inp.isnumeric():
            guessOP = sendrecv_dict(client_sock, {"op":"GUESS","number":new_send})
            print("Tens mais: " , max_attempts - len(trys) , " tentativas\n")
            
       
        
        number = int(inp)
        msg = {'op': 'GUESS', 'number': encrypt_intvalue(cipherkey, number)}
        attempts+=1
        new_send = encrypt_intvalue(key, new)
        guessOP = sendrecv_dict(client_sock, {"op":"GUESS","number":new_send})
	    # validate_response(client_sock,guessOP)
        trys.append([new , guessOP["result"]])
					
        print("O número secreto é " + guessOP["result"]+"\n")
        if guessOP["result"] == "equals":
    	    print("Chegaste ao número secreto em", len(trys),"tentativas!")
    	    attempts_send = encrypt_intvalue(key, len(trys))
    	    stopOP = sendrecv_dict(client_sock,{"op":"STOP","number":new_send,"attempts":attempts_send})
    	    # validate_response(client_sock,stopOP)
    	    return None


    print("Excedeste o número máximo de " + str(max_attempts) + " jogadas!")
    quit_action(client_sock,max_attempts)

def run_client(client_sock, client_id):
    print("\t\tOlá", client_id, "vamos jogar!\n")
    print("\t\t\tREGRAS DO JOGO: \n")
    print("\t - Tente adivinhar o número secreto gerado aleatoriamente\n")
    print("\t - Existe um número máximo de tentativas que não deve ser ultrapassado para ter sucesso\n")

    cript = input("Deseja usar mensagens encriptadas? s ou n? ")

    key = None

    if cript.lower() == "s":
        key = str(base64.b64encode(os.urandom(16)), 'utf8')

    resp = sendrecv_dict(client_sock, {"op": "START", "client_id": client_id, "cipher": key})
    validate_response(client_sock, resp)

    max_attempts = decrypt_intvalue(key, resp.get("max_attempts"))
    trys = []

    print("Entraste no jogo!\n", "Tens ", max_attempts, "tentativas.\n")

    while len(trys) < max_attempts:
        print("Tens mais: " + max_attempts - len(trys) + " tentativas\n")

        new = input("Tenta de novo:  ")
        if new.lower() == "quit":
            quit_action(client_sock, len(trys))
            print("Introduza um número!!\n")

    new_send = encrypt_intvalue(key, new)
    guessOP = sendrecv_dict(client_sock, {"op": "GUESS", "number": new_send})
    validate_response(client_sock, guessOP)
    trys.append([new, guessOP["result"]])

    print("Secret Number is " + guessOP["result"] + "\n")
    if guessOP["result"] == "equals":
        print("Chegou ao número secreto em", len(trys), "tentativas!")
        attempts_send = encrypt_intvalue(key, len(trys))
        stopOP = sendrecv_dict(client_sock, {"op": "STOP", "number": new_send, "attempts": attempts_send})
        validate_response(client_sock, stopOP)
        return None

    print("Excedeste o número máximo de " + str(max_attempts) + " jogadas!")
    quit_action(client_sock, max_attempts)


def valid_argv(argv):
    # validação da quantidade de argumentos recebidos
    if (len(sys.argv) < 3):
        sys.exit("ERROR! INSUFICIENT ARGUMENTS! Please try: python3 client.py client_id porto [máquina]")

    elif (len(sys.argv) > 4):
        sys.exit("ERROR! TOO MANY ARGUMENTS! Please try: python3 client.py client_id porto [máquina]")

    # validação do tipo do tipo de dados

    try:
        val = int(sys.argv[2])
    except ValueError:
        sys.exit("ERROR! TYPE OF ARGUMENTS INVALID! port must be integer!")

    if (val <= 0):
        sys.exit("ERROR! TYPE OF ARGUMENTS INVALID! port must be positive!")

    # validação do tipo e da estrutura do argumento 4
    if (len(sys.argv) == 4):
        arg = sys.argv[3].split(".")
        if (len(arg) != 4):
            sys.exit("Server adress is not a valid IPv4 or DNS")
            return
        else:
            for c in arg:
                try:
                    c = float(c)
                except ValueError:
                    sys.exit("Server adress is not a valid IPv4 or DNS")
                    return
                if (c < 0 or c > 250):
                    sys.exit("Server adress is not a valid IPv4 or DNS")
                    return
    return


def main():
    # validate the number of arguments and eventually print error message and exit with error
    # verify type of of arguments and eventually print error message and exit with error

    valid_argv(sys.argv)
    # valor inteiro positivo, especificando o porto
    port = int(sys.argv[2])

    # Se não existir 4º elemento, hostname = localhost
    if len(sys.argv) == 4:
        hostname = sys.argv[3]
    else:
        hostname = "127.0.0.1"

    client_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_sock.connect((hostname, port))

    run_client(client_sock, sys.argv[1])

    client_sock.close()
    sys.exit(0)


if __name__ == "__main__":
    main()
