#!/usr/bin/python3

import sys
import socket
import select
import json
import base64
import csv
import random
from common_comm import send_dict, recv_dict, sendrecv_dict

from Crypto.Cipher import AES

# Dicionário com a informação relativa aos clientes
gamers = {}

# return the client_id of a socket or None
def find_client_id (client_sock):
	for id in gamers:
		if gamers[id]["socket"] == client_sock:
			return id
	return None

# Função para encriptar valores a enviar em formato json com codificação base64
# return int data encrypted in a 16 bytes binary string and coded base64
def encrypt_intvalue (client_id, data):
	cipher = gamers[client_id]['cipher']
	if not cipher:
		return data
	encrypted = cipher.encrypt(bytes("%16d" % (data),'utf8'))
	tosend = str(base64.b64encode(encrypted),'utf8')

	return tosend


# Função para desencriptar valores recebidos em formato json com codificação base64
# return int data decrypted from a 16 bytes binary string and coded base64
def decrypt_intvalue (client_id, data):
	cipher = gamers[client_id]['cipher']
	if not cipher:
		return data
	decrypt = cipher.decrypt(base64.b64decode(data))
	decrypt = int(str(decrypt, 'utf8'))
	return decrypt


#
# Incomming message structure:
# { op = "START", client_id, [cipher] }
# { op = "QUIT" }
# { op = "GUESS", number }
# { op = "STOP", number, attempts }
#
# Outcomming message structure:
# { op = "START", status, max_attempts }
# { op = "QUIT" , status }
# { op = "GUESS", status, result }
# { op = "STOP", status, guess }


#
# Suporte de descodificação da operação pretendida pelo cliente
#
def new_msg (client_sock):

	# read the client request
	request = recv_dict(client_sock)
	print('Command: %s' % (str(request)))
	
	# detect the operation requested by the client
	# execute the operation and obtain the response (consider also operations not available)
	
	# outmsg = None

	if request["op"] == "START":
		outmsg = new_client(client_sock, request)
	elif request["op"] == "GUESS":
		outmsg = guess_client(client_sock, request)	
	elif request["op"]=="STOP":
		outmsg = stop_client(client_sock, request)
	elif request["op"]=="QUIT":
		outmsg = quit_client(client_sock, request)
	else:
		outmsg =  {'error':'Wrong request "' + request['op'] + '"' }

	# send the response to the client
	send_dict(client_sock, request)


#
# Suporte da criação de um novo jogador - operação START
#
def new_client (client_sock, request):

	# detect the client in the request
	client = request['client_id']
	
	# detect if the client already exists:
	# verify the appropriate conditions for executing this operation
	if client == None:
		return {"op": "START", "status": False, "error": "Cliente existente" }

	# obtain the secret number and number of attempts
	secret_number = random.randint(0, 100)
	max_attempts = random.randint(10,30)

	
	# process the client in the dictionary
	gamers[client] = {"socket":client_sock,"cipher":None,"guess":secret_number,"max_attempts": max_attempts ,"attempts" : 0}

	if request["cipher"]:
		key = base64.b64decode(request['cipher'])
		gamers[client]['cipher'] = AES.new(key, AES.MODE_ECB)
	
	max_attempts = encrypt_intvalue(client, max_attempts)

	
	# return response message with results or error message
	return {"op": "START", "status": True, "max_attempts": max_attempts}


#
# Suporte da eliminação de um cliente
#
# obtain the client_id from his socket and delete from the dictionary
def clean_client (client_sock):

	client_id = find_client_id(client_sock)

	if client_id:
		del gamers[client_id]
		return True
	return False



#
# Suporte do pedido de desistência de um cliente - operação QUIT
#
def quit_client (client_sock, request):
	
	# obtain the client_id from his socket
	client_id = find_client_id(client_sock)

	# verify the appropriate conditions for executing this operation
	if client_id not in gamers:
		return {"op": "QUIT", "status": False, "error": "Cliente inexistente"}
	
	else:
		# process the report file with the QUIT result
		update_file(client_id, 'QUIT')
		
		# eliminate client from dictionary
		clean_client(client_sock)
		
		# return response message with result or error message
		return {"op": "QUIT", "status": True }
	

#
# Suporte da criação de um ficheiro csv com o respectivo cabeçalho
#
def create_file ():
	# create report csv file with header
	with open("report.csv" , "w") as file:
		wrt = csv.writer(file)
		wrt.writerow(["ID do cliente","Número secreto", "Nº máximo de jogadas" , "Nº de jogadas realizadas","Resultado"])

#
# Suporte da actualização de um ficheiro csv com a informação do cliente e resultado
#
def update_file (client_id, result):
	# update report csv file with the result from the client
	client = gamers[client_id]

	with open("report.csv" , "a+") as file:
		wrt = csv.writer(file)
		wrt.writerow(client_id, client["guess"], client["max_attempts"], client["attempts"], result)

#
# Suporte da jogada de um cliente - operação GUESS
#
def guess_client (client_sock, request):
	
	# obtain the client_id from his socket
	client_id = find_client_id(client_sock)

	# verify the appropriate conditions for executing this operation
	
	# return response message with result or error message
	if client_id:
		
		gamers[client_id]["attempts"]+=1
		number = decrypt_intvalue(client_id, request["number"])
		secret_number = gamers[client_id]["guess"]
		result = "equals"

		if number < secret_number:
			result = "larger"
		elif number > secret_number:
			result = "smaller"
		elif number == secret_number:
			result = "equals"

		return {"op": "GUESS", "status": True, "result": result}
	
	else:
		return {"op": "GUESS", "status": False, "error": "Cliente inexistente"}



#
# Suporte do pedido de terminação de um cliente - operação STOP
#
def stop_client (client_sock, request):
	
	# obtain the client_id from his socket
	client_id = find_client_id(client_sock)
	
	# verify the appropriate conditions for executing this operation
	if not client_id in gamers:
		return {"op":"STOP","status":False,"error":"Cliente inexistente"}

	attempts = decrypt_intvalue(client_id, request["attempts"])
	decrypt = decrypt_intvalue(client_id, request["number"])

	if gamers[client_id]["attempts"] != attempts:
                return {"op":"STOP","status":False,"error":"Número de jogadas inconsistente"}
	
	# process the report file with the SUCCESS/FAILURE result
	if gamers[client_id]["attempts"] <= gamers[client_id]["max_attempts"] and gamers[client_id]["guess"] == decrypt:
		update_file(client_id, "SUCCESS")
	else:
		update_file(client_id, "FAILURE")

	# eliminate client from dictionary
	clean_client(client_sock)

	# return response message with result or error message
	return {"op":"STOP","status":True,"guess": decrypt}


def valid_argv(argv):

	if (len(sys.argv) < 2):
		sys.exit("ERROR! INSUFICIENT ARGUMENTS! Please try: python3 server.py porto")

	if (len(sys.argv) > 2):
		sys.exit("ERROR! TOO MANY ARGUMENTS! Please try: python3 server.py porto")

	try:
		val = int(sys.argv[1])

	except ValueError:
		sys.exit("ERROR! TYPE OF ARGUMENTS INVALID! port must be integer! ")


def main():
	# validate the number of arguments and eventually print error message and exit with error
	# verify type of of arguments and eventually print error message and exit with error
	valid_argv()

	# valor inteiro positivo, especificando o porto
	port = int(sys.argv[1])

	server_socket = socket.socket (socket.AF_INET, socket.SOCK_STREAM)
	server_socket.bind (("127.0.0.1", port))
	server_socket.listen (10)

	print("Server running on port: " + str(port))


	clients = []
	create_file ()

	while True:
		try:
			available = select.select ([server_socket] + clients, [], [])[0]
		except ValueError:
			# Sockets may have been closed, check for that
			for client_sock in clients:
				if client_sock.fileno () == -1: client_sock.remove (client) # closed
			continue # Reiterate select

		for client_sock in available:
			# New client?
			if client_sock is server_socket:
				newclient, addr = server_socket.accept ()
				clients.append (newclient)
			# Or an existing client
			else:
				# See if client sent a message
				if len (client_sock.recv (1, socket.MSG_PEEK)) != 0:
					# client socket has a message
					##print ("server" + str (client_sock))
					new_msg (client_sock)
				else: # Or just disconnected
					clients.remove (client_sock)
					clean_client (client_sock)
					client_sock.close ()
					break # Reiterate select

if __name__ == "__main__":
	main()
