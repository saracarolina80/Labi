from Crypto.Cipher import AES
import base64
from Crypto import Cipher
from Crypto.Cipher import AES
import pytest
import os
import sys
import crypt
import client
import server


# TESTES FUNCIONAIS

def test_f_1():
    print("Testa comportamento encrypt_intvalue")
    assert client.encrypt_intvalue("123", 3) == str(base64.b64encode(encrypted), 'utf8')



def test_f_2():
    print("Testa comportamento decrypt_intvalue")
    assert client.decrypt_intvalue(int(str(decrypted, 'utf8'),3)
) == "123"


def test_f_3():

    # teste para nºargumentos <3
    assert client.valid_argv(["",""]) == "ERROR! INSUFICIENT ARGUMENTS! Please try: python3 client.py client_id porto [máquina]"
    # teste para nºargumentos >4
    assert client.valid_argv(["","","","",""]) == "ERROR! TOO MANY ARGUMENTS! Please try: python3 client.py client_id porto [máquina]"
    # teste de argumento do tipo errado
    assert client.valid_argv(["client.py","name","abc"]) == "ERROR! TYPE OF ARGUMENTS INVALID! port must be integer!"
    assert client.valid_argv(["client.py","name","-1"]) == "ERROR! TYPE OF ARGUMENTS INVALID! port must be positive!"
